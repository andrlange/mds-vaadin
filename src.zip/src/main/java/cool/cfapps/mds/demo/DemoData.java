package cool.cfapps.mds.demo;

import lombok.AllArgsConstructor;
import lombok.Data;


public interface DemoData {
}
