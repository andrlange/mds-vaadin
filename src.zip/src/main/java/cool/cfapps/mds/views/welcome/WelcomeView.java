package cool.cfapps.mds.views.welcome;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.security.AuthenticationContext;
import cool.cfapps.mds.infrastructure.SecurityService;
import jakarta.annotation.security.PermitAll;
import lombok.extern.slf4j.Slf4j;


@Route("welcome")
@PageTitle("Welcome")
@PermitAll
@Slf4j
public class WelcomeView extends VerticalLayout {


    public WelcomeView(SecurityService securityService, AuthenticationContext authenticationContext) {


        log.info("Welcome view loaded for user: {}", authenticationContext.getPrincipalName());
        add(new Div("Welcome to the logged in System!"));

        Button logoutButton = new Button("Logout");
        logoutButton.addClickListener(event -> {
            if (authenticationContext.getPrincipalName() != null && authenticationContext.getPrincipalName().isPresent()) {
                securityService.logout(authenticationContext.getPrincipalName().get());
            } else {
                log.info("User is not logged in");
            }


        });

        add(logoutButton);

    }
}
