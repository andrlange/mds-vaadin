package cool.cfapps.mds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiDataApplicationTests {

    @Test
    void contextLoads() {
    }

}
